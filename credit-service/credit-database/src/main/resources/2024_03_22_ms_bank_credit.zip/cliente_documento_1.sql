create table cliente_documento
(
    cliente_id   bigint not null,
    documento_id int    not null,
    primary key (cliente_id, documento_id),
    constraint UK_lw8t46qj5bsm2t0jxhefbw36t
        unique (documento_id),
    constraint FKcugpxxpxobf5gq9ldvhxkhb3r
        foreign key (cliente_id) references cliente (id),
    constraint FKlury5mxjolgl1jg8b2l1esgfg
        foreign key (documento_id) references documento (id)
);

