INSERT INTO bank_credit.user (id, name, senha) VALUES (1, 'admin', 'strong');
INSERT INTO bank_credit.user (id, name, senha) VALUES (2, 'armando', 'weak');
INSERT INTO bank_credit.user (id, name, senha) VALUES (3, 'caixa', 'caixa');
INSERT INTO bank_credit.user (id, name, senha) VALUES (4, 'gestor', 'gestor');
