create table garantia
(
    id            int auto_increment
        primary key,
    descricao     varchar(255) null,
    docb64        varchar(255) null,
    credito_id_id bigint       null,
    constraint FKllbynt2qlefybxygr7v2fug5l
        foreign key (credito_id_id) references credito (id)
);

