create table documento
(
    id            int          not null
        primary key,
    data_emissao  date         null,
    data_validade date         null,
    numero        varchar(255) null,
    tipo          varchar(255) null,
    client_id     bigint       null,
    constraint FK4vdj0el4fv7wsgi8xp82p7rkb
        foreign key (client_id) references cliente (id)
);

