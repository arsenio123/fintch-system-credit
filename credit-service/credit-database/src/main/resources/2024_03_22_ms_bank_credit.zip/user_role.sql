INSERT INTO bank_credit.user_role (user_id, role_id) VALUES (1, 1);
INSERT INTO bank_credit.user_role (user_id, role_id) VALUES (1, 2);
INSERT INTO bank_credit.user_role (user_id, role_id) VALUES (1, 3);
INSERT INTO bank_credit.user_role (user_id, role_id) VALUES (1, 4);
INSERT INTO bank_credit.user_role (user_id, role_id) VALUES (2, 1);
