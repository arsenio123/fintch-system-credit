create table prestacao
(
    id                     bigint auto_increment
        primary key,
    capital_pago           double       not null,
    conta_creditada        bigint       not null,
    data_pagamento         date         null,
    estado                 varchar(255) null,
    jurus_pago             double       not null,
    valor_capita_por_pagar double       not null,
    vencimento             date         null,
    capital_id             bigint       null,
    credito_id             bigint       null,
    intrest_id             bigint       null,
    constraint FK5neofu7bqrcdy1ue3ygty963a
        foreign key (credito_id) references credito (id),
    constraint FK6k5h6l4dtbhbqpcm0weahphpr
        foreign key (capital_id) references capital (id),
    constraint FKapejtt9gmg66tc44vt994r3y2
        foreign key (intrest_id) references intrest (id)
);

INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (2, 200, 456, '2023-12-15', 'EM_VIGOR', 0, 1000, '2023-11-30', null, 202, 753);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (3, 200, 456, '2023-12-15', 'EM_VIGOR', 0, 1000, '2023-11-30', null, 202, 802);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (4, 0, 0, '2023-12-12', 'EM_VIGOR', 0, 0, '2023-11-30', 302, 202, 852);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (5, 0, 0, '2024-01-29', 'EM_VIGOR', 0, 0, '2024-01-29', 50002, 50302, 50052);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (6, 0, 0, '2024-01-31', 'EM_VIGOR', 0, 0, '2024-01-29', 50052, 50302, 50055);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (7, 0, 0, '2023-01-12', 'EM_VIGOR', 0, 0, '2023-01-12', 99952, 99952, 99953);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (8, 0, 0, '2023-02-13', 'EM_VIGOR', 0, 0, '2023-02-12', 99953, 99952, 99955);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (9, 0, 0, '2024-03-04', 'EM_VIGOR', 0, 0, '2023-03-17', 99954, 99952, 99957);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (10, 0, 0, '2024-04-12', 'EM_VIGOR', 0, 0, '2023-04-12', 99955, 99952, 99959);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (11, 0, 0, '2024-03-05', 'EM_VIGOR', 0, 0, '2023-05-18', 99956, 99952, 100002);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (12, 0, 0, '2024-03-05', 'EM_VIGOR', 0, 0, '2023-06-20', 100002, 99952, 100003);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (13, 0, 0, '2024-03-20', 'EM_VIGOR', 0, 0, '2023-11-30', 452, 202, 100052);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (14, 0, 0, '2024-03-20', 'EM_VIGOR', 0, 0, '2023-11-30', 100052, 202, 100053);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (15, 0, 0, '2024-03-20', 'EXPIRADO', 0, 0, '2023-11-30', 100053, 202, 100054);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (16, 0, 0, '2024-03-20', 'EXPIRADO', 0, 0, '2023-11-30', 100054, 202, 100055);
INSERT INTO ms_bank_credit.prestacao (id, capital_pago, conta_creditada, data_pagamento, estado, jurus_pago, valor_capita_por_pagar, vencimento, capital_id, credito_id, intrest_id) VALUES (17, 0, 0, '2024-03-20', 'EM_VIGOR', 0, 0, '2023-11-30', 100055, 202, 100056);
