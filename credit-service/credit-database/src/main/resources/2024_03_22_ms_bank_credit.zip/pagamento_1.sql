create table pagamento
(
    id                bigint       not null
        primary key,
    conta             bigint       not null,
    created_bay       bigint       null,
    data_de_pagametno date         null,
    forma_pagamento   varchar(255) null,
    valor_pago        double       not null,
    capital_id        bigint       null,
    intrest_id        bigint       null,
    prestacao_id      bigint       null,
    constraint FKexxndsovui1aw3hycqnici94k
        foreign key (intrest_id) references intrest (id),
    constraint FKouyplbsb7hdwrnb1tix8krn2f
        foreign key (capital_id) references capital (id),
    constraint FKplp9nw5kat8j0bbi72uofdic7
        foreign key (prestacao_id) references prestacao (id)
);

INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (1, 121212, 1, '2023-12-13', 'conta', 2000, 452, 952, 4);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (49952, 3434, 1, '2024-01-29', 'manual', 444, 50052, 50053, 5);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (99952, 1212123, 1, '2023-01-12', 'BIM', 218750, 99953, 99954, 7);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (99953, 323234, 1, '2023-02-13', 'Moza', 218750, 99954, 99956, 8);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (99954, 32434, 1, '2023-03-17', 'BCI', 218750, 99955, 99958, 9);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (100002, 323232, 1, '2023-06-30', 'MyBacks', 218750, 100003, 100004, 10);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (100003, 323232, 1, '2023-06-30', 'MyBacks', 218750, 100003, 100005, 11);
INSERT INTO ms_bank_credit.pagamento (id, conta, created_bay, data_de_pagametno, forma_pagamento, valor_pago, capital_id, intrest_id, prestacao_id) VALUES (100004, 323232, 1, '2023-06-30', 'MyBacks', 662500, 100004, 100006, 12);
