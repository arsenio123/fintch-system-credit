create table credito
(
    id                bigint       not null
        primary key,
    aprovadopor       bigint       null,
    balance           double       not null,
    begin_date        date         null,
    created_by        bigint       null,
    created_date      datetime(6)  null,
    do_date           date         null,
    estado            varchar(255) null,
    jurus             double       not null,
    proxima_prestacao date         null,
    update_date       datetime(6)  null,
    valor             bigint       not null,
    cliente_id        bigint       null,
    producto_id       bigint       null,
    constraint FKaf11sd60htxisxvkmrkny1h0y
        foreign key (cliente_id) references cliente (id),
    constraint FKt28eo88scg9shcamkara85que
        foreign key (producto_id) references producto (id)
);

INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (202, 2002, 0, '2023-11-30', 1001, '2023-12-01 13:59:47.274142', '2023-12-01', 'VIGOR', 0.05, '2023-12-15', '2023-12-01 13:59:47.274142', 50000, 1, 1);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (50102, null, 0, null, null, '2024-01-26 09:49:44.819704', null, 'PENDENTE', 13, null, '2024-01-26 09:49:44.819704', 1000, 1, 1);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (50152, null, 0, null, null, '2024-01-26 09:58:51.101798', null, 'PENDENTE', 13, null, '2024-01-26 09:58:51.101798', 1000, 1, 1);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (50202, null, 0, null, null, '2024-01-26 10:00:05.788287', null, 'PENDENTE', 13, null, '2024-01-26 10:00:05.788287', 1000, 1, 1);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (50252, 3, 0, '2023-11-30', 3, '2024-03-05 12:07:13.829792', '2024-12-04', 'PENDENTE', 0.05, '2023-12-15', '2024-03-05 12:07:13.829792', 50000, 1, 2);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (50253, 3, 0, '2024-01-29', 3, '2024-01-29 14:51:42.797352', '2024-07-29', 'VIGOR', 0, '2024-01-29', '2024-01-29 14:51:42.797352', 10000, 1, 2);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (50302, 1, 0, '2024-01-29', 1, '2024-01-29 15:12:14.702884', '2024-04-29', 'VIGOR', 0, '2024-01-29', '2024-01-29 15:12:14.702884', 30000, 1, 2);
INSERT INTO ms_bank_credit.credito (id, aprovadopor, balance, begin_date, created_by, created_date, do_date, estado, jurus, proxima_prestacao, update_date, valor, cliente_id, producto_id) VALUES (99952, 1, 0, '2022-12-12', 1, '2024-03-04 13:00:06.805033', '2024-12-31', 'VIGOR', 0, '2024-03-04', '2024-03-04 13:00:06.805033', 3500000, 3, 3);
