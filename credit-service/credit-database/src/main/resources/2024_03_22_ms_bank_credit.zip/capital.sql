create table capital
(
    id          bigint       not null
        primary key,
    descricao   varchar(255) null,
    envent_date datetime(6)  null,
    valor       double       null,
    credito_id  bigint       null,
    constraint FKflde5uoioht42thrr2f2tu6o0
        foreign key (credito_id) references credito (id)
);

INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (252, 'Valor de desembolso', '2023-12-01 13:59:47.378137', 50000, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (253, 'saldo apos prestacao', '2023-12-01 14:01:29.318703', 50000, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (302, 'saldo apos prestacao', '2023-12-04 10:38:01.779633', 50000, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (352, 'saldo apos prestacao', '2023-12-12 17:59:44.577672', 50000, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (402, 'Amortizacao do capital', '2023-12-13 10:44:49.979923', 48075, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (452, 'Amortizacao do capital', '2023-12-13 10:46:23.082164', 46075, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (49952, 'Valor de desembolso', '2024-01-26 10:00:05.908284', 1000, 50202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (50002, 'Valor de desembolso', '2024-01-29 15:12:14.764896', 30000, 50302);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (50052, 'saldo apos prestacao', '2024-01-29 16:52:58.333394', 30000, 50302);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (50053, 'saldo apos prestacao', '2024-01-31 11:22:00.085022', 30000, 50302);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (99952, 'Valor de desembolso', '2024-03-04 13:00:06.824988', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (99953, 'saldo apos prestacao', '2024-03-04 13:06:27.703961', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (99954, 'saldo apos prestacao', '2024-03-04 15:23:37.646531', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (99955, 'saldo apos prestacao', '2024-03-04 16:01:11.913805', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (99956, 'saldo apos prestacao', '2024-03-04 16:22:55.690167', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100002, 'saldo apos prestacao', '2024-03-05 09:07:34.665685', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100003, 'saldo apos prestacao', '2024-03-05 09:09:08.222942', 3500000, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100004, 'Amortizacao do capital', '2024-03-05 09:28:33.028634', 3056250, 99952);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100005, 'Valor de desembolso', '2024-03-05 12:07:13.875844', 50000, 50252);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100052, 'saldo apos prestacao', '2024-03-20 15:13:18.533025', 46075, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100053, 'saldo apos prestacao', '2024-03-20 15:37:48.170964', 46075, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100054, 'saldo apos prestacao', '2024-03-20 15:40:37.361234', 46075, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100055, 'saldo apos prestacao', '2024-03-20 15:40:42.749505', 46075, 202);
INSERT INTO ms_bank_credit.capital (id, descricao, envent_date, valor, credito_id) VALUES (100056, 'saldo apos prestacao', '2024-03-20 15:40:52.711163', 46075, 202);
