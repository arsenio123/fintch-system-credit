create table cliente
(
    id              bigint auto_increment
        primary key,
    data_nascimento date         null,
    email           varchar(255) null,
    id_doc          varchar(255) null,
    morada          varchar(255) null,
    nome            varchar(255) null,
    number_doc      varchar(255) null,
    rendimento      int          null,
    setor           smallint     null,
    telefone        varchar(255) null,
    constraint UK_e5adkv05suc42e6s3k45136by
        unique (number_doc)
);

INSERT INTO ms_bank_credit.cliente (id, data_nascimento, email, id_doc, morada, nome, number_doc, rendimento, setor, telefone) VALUES (1, '2023-10-31', 'fdsfg.fg@example.com', 'YTR123', '123 Main Street', 'Doe Jhon', '54354645', 50000, 0, '123-456-7890');
INSERT INTO ms_bank_credit.cliente (id, data_nascimento, email, id_doc, morada, nome, number_doc, rendimento, setor, telefone) VALUES (2, '2023-12-26', 'dd@gmail.com', '', '', 'DD', '23434356', 256780, 0, '898909876');
INSERT INTO ms_bank_credit.cliente (id, data_nascimento, email, id_doc, morada, nome, number_doc, rendimento, setor, telefone) VALUES (3, '2024-03-04', 'sfdasdfd@gmail.com', 'IB', '', 'WD', '', 20000, 0, '878888443');
