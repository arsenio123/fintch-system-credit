INSERT INTO bank_credit.role (id, descricao) VALUES (1, 'ROLE_GARANTIAS');
INSERT INTO bank_credit.role (id, descricao) VALUES (2, 'ROLE_CREDITOS');
INSERT INTO bank_credit.role (id, descricao) VALUES (3, 'ROLE_ALL');
INSERT INTO bank_credit.role (id, descricao) VALUES (4, 'ROLE_ADMIN');
