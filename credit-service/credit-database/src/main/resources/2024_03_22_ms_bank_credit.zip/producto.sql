INSERT INTO bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (1, 1000, 100, 'credito valeor 1000', 0, 0, 5);
INSERT INTO bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (2, 100, 10, 'Credito ja 100', 0, 0, 5);
INSERT INTO bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (3, 100, 10, 'junir start up', 0, 0, 5);
INSERT INTO bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (4, 100, 10, 'Credito Mulher', 0, 0, 5);
