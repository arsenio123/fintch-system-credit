create table role_autorite
(
    id      bigint not null,
    auth_id bigint not null,
    primary key (id, auth_id),
    constraint FKqknfbtskw13qbefybs44agtfg
        foreign key (id) references role (id),
    constraint FKsc9fh05ua47qvm1je3benh3y7
        foreign key (auth_id) references authority (auth_id)
);

INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 1);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 2);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 3);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 4);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 6);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 7);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 8);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 9);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 10);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 12);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 13);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 14);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 15);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 16);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 17);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 18);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 19);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 20);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 21);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 22);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 23);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 26);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 27);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (1, 28);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (2, 1);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (2, 4);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (3, 24);
INSERT INTO accessdev.role_autorite (id, auth_id) VALUES (3, 25);
