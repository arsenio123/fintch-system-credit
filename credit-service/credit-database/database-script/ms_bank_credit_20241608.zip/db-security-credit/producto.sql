create table producto
(
    id                  bigint auto_increment
        primary key,
    capital_max         bigint       not null,
    capital_min         bigint       not null,
    descricao           varchar(255) null,
    estado              smallint     null,
    intervalo_prestacao int          not null,
    taxa                double       null
);

INSERT INTO ms_bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (1, 5000, 1000, 'Descrição do produto', 1, 15, 0.05);
INSERT INTO ms_bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (2, 1000000, 10000, 'Sonho Jr', 1, 0, 23);
INSERT INTO ms_bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (3, 100000000, 10000, 'Corporate', 1, 30, 6.25);
INSERT INTO ms_bank_credit.producto (id, capital_max, capital_min, descricao, estado, intervalo_prestacao, taxa) VALUES (4, 30000000, 1000, 'stand', 1, 30, 0.15);
