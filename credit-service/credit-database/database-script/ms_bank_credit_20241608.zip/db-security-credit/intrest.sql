create table intrest
(
    id          bigint       not null
        primary key,
    descricao   varchar(255) null,
    envent_date datetime(6)  null,
    valor       double       null,
    credito_id  bigint       null,
    constraint FKu7c07wr2w617yfy1lo396g3y
        foreign key (credito_id) references credito (id)
);

INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (752, null, '2023-12-01 13:59:47.387137', 0, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (753, null, '2023-12-01 14:01:29.303702', 25, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (802, null, '2023-12-04 10:38:01.737633', 50, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (852, null, '2023-12-12 17:59:44.502611', 75, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (902, null, '2023-12-13 10:44:49.956528', 0, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (952, null, '2023-12-13 10:46:23.037112', 0, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (49952, null, '2024-01-26 10:00:05.918282', 0, 50202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (50002, null, '2024-01-29 15:12:14.772897', 0, 50302);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (50052, null, '2024-01-29 16:52:58.306398', 6900, 50302);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (50053, null, '2024-01-29 16:53:51.441323', 6456, 50302);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (50054, null, '2024-01-31 11:20:20.473878', 130, 50202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (50055, null, '2024-01-31 11:22:00.072988', 13356, 50302);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99952, null, '2024-03-04 13:00:06.824988', 0, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99953, null, '2024-03-04 13:06:27.688317', 218750, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99954, null, '2024-03-04 14:15:34.787822', 0, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99955, null, '2024-03-04 15:23:37.634934', 218750, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99956, null, '2024-03-04 15:29:23.058305', 0, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99957, null, '2024-03-04 16:01:11.897085', 218750, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99958, null, '2024-03-04 16:13:33.383199', 0, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (99959, null, '2024-03-04 16:22:55.684409', 218750, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100002, null, '2024-03-05 09:07:34.643069', 437500, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100003, null, '2024-03-05 09:09:08.217361', 656250, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100004, null, '2024-03-05 09:26:02.341014', 437500, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100005, null, '2024-03-05 09:26:24.988599', 218750, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100006, null, '2024-03-05 09:28:33.023632', 0, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100007, null, '2024-03-05 12:07:13.880877', 0, 50252);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100052, null, '2024-03-20 15:13:18.483618', 23.0375, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100053, null, '2024-03-20 15:37:48.161962', 46.075, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100054, null, '2024-03-20 15:40:37.353192', 69.11250000000001, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100055, null, '2024-03-20 15:40:42.741535', 92.15, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (100056, null, '2024-03-20 15:40:52.701167', 115.1875, 202);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (149952, null, '2024-04-19 12:08:25.800210', 0, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (149953, null, '2024-04-19 12:11:52.391686', 0, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (149954, null, '2024-04-19 12:13:15.171545', 0, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (199952, null, '2024-05-13 11:37:22.807781', 0, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200002, null, '2024-05-13 12:01:03.897278', 0, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200052, null, '2024-05-14 17:07:08.785034', 59400, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200053, null, '2024-05-14 17:10:24.637184', 0, 149952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200054, null, '2024-05-14 17:13:45.451361', 0, 99952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200102, null, '2024-05-16 15:37:35.799665', 0, 199952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200103, null, '2024-05-16 15:37:56.944857', 1500, 199952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (200152, null, '2024-05-21 16:37:08.203736', 0, 199952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (249952, null, '2024-05-26 16:46:23.769779', 0, 249952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (249953, null, '2024-05-26 16:47:37.207443', 3000, 249952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (299952, null, '2024-06-14 10:27:55.916309', 130, 50102);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (300002, null, '2024-06-14 10:47:54.897399', 0, 299952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (300052, null, '2024-06-14 10:50:42.480741', 1.5, 299952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (300102, null, '2024-06-14 10:56:22.506351', 3, 299952);
INSERT INTO ms_bank_credit.intrest (id, descricao, envent_date, valor, credito_id) VALUES (349952, null, '2024-07-17 08:57:19.681575', 0, 99952);
