create table user
(
    id    bigint       not null
        primary key,
    name  varchar(255) null,
    senha varchar(255) null
);

INSERT INTO accessdev.user (id, name, senha) VALUES (1, 'admin', 'strong');
INSERT INTO accessdev.user (id, name, senha) VALUES (2, 'caixa', 'pass');
INSERT INTO accessdev.user (id, name, senha) VALUES (3, 'supervisor', 'strong');
